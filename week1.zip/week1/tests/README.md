# Steps to run tests:

- navigate to result-generator folder.
- insert the command on Terminal:

```bash
npm install

```

- after done that for every file, you can run the tests on the terminal:

```bash
This command will run all the tests, all the files
npm test
```

- if you want to run a specific test file, you can run:

```bash
In this case, only the tests inside of the chosen file will run
npm test fileName.test.js
```
